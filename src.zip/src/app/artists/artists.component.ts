import { Component, OnInit } from '@angular/core';
import { Artist } from './artist';

@Component({
  selector: 'app-artists',
  templateUrl: './artists.component.html',
  styleUrls: ['./artists.component.css']
})
export class ArtistsComponent implements OnInit {

artistListTitle: string ='List of Artists';
list_Search:string='';

artistList: Artist[];

  constructor() {
    this.list_Search='';
    this.artistList=this.artists;
   }

   get listSearch(): string{
     return this.list_Search;
   }

   set listSearch(value:string){
     this.list_Search= value;
     this.artistList=this.list_Search ? this.doArtistSearch(this.list_Search):this.artists;
   }

  artists: Artist[]=[{
    "artistName" : "Ghazal Khanna",
    "genre" : "Poetry",
    "contact" : "contactghazal@gmail.com",
    "artistRating" : 4.5
  },
  {
    "artistName" : "Kanwal",
    "genre" : "Painting",
    "contact" : "kanwal@gmail.com",
    "artistRating" : 4.4
  },
  {
    "artistName" : "Dibya",
    "genre" : "Comedy",
    "contact" : "dibyal@gmail.com",
    "artistRating" : 4.8
  }
]

  ngOnInit() {
  }

  doArtistSearch(searchBy:string):Artist[]{
    searchBy=searchBy.toLowerCase();
    return this.artists.filter(artist => artist.artistName.toLowerCase().indexOf(searchBy)!==-1);
  }

}
