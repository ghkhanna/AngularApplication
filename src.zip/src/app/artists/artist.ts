export interface Artist {
    artistName: string,
    genre: string,
    contact : string,
    artistRating: number
}
